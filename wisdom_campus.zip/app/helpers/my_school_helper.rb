module MySchoolHelper
end
