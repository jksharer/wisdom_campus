module MainPagesHelper
end
