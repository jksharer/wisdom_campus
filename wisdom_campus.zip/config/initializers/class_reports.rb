# 每次重启服务器/重新加载整个应用时，更新在校班级学生和行为数量统计
include ApplicationHelper

update_all_report