# require 'rufus-scheduler'
# require 'class_report'

# scheduler = Rufus::Scheduler.new

# scheduler.every '30s' do
# 	puts "start update class reports......"
# 	ClassReport.update_reports_every_minute
# end

# scheduler.join