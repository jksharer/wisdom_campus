
Encoding.default_internal = 'UTF-8'

# Load the Rails application.
require File.expand_path('../application', __FILE__)

# Initialize the Rails application.
WisdomCampus::Application.initialize!
